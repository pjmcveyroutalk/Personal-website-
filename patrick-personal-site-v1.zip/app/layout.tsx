import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Patrick McVey II | Routalk Build",
  description: "Turning business problems and ideas into practical digital solutions.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
