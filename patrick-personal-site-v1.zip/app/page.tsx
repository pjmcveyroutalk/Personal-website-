const services = [
  ["Websites", "Modern business websites built around your customers and goals."],
  ["Custom Applications", "Web applications designed around specific business needs."],
  ["Automation", "Reduce repetitive work and unnecessary manual processes."],
  ["Internal Tools", "Dashboards and systems that make everyday operations easier."],
  ["Customer Experiences", "Forms, portals, application systems, and custom interactions."],
  ["AI-Assisted Solutions", "Practical uses of AI where it can provide genuine value."],
];

const projects = [
  {
    name: "MVDr. Gabriela Šulovská",
    type: "Brand Identity · Business Website",
    text: "A complete digital presence combining branding, structure, and development for a professional veterinary practice.",
  },
  {
    name: "Valpe",
    type: "Custom Catalog · Data Architecture",
    text: "A custom digital experience showing how substantial business information can be organized into something useful and approachable.",
  },
  {
    name: "Betánia Senec",
    type: "Website · Complex Content",
    text: "A content-rich experience demonstrating thoughtful information architecture, design, and development.",
  },
];

const steps = [
  ["01", "Talk", "Tell me about your business, idea, or problem."],
  ["02", "Understand", "We figure out what you're actually trying to accomplish."],
  ["03", "Shape", "We determine what makes sense to build and what doesn't."],
  ["04", "Build", "Xin leads primary technical implementation while I stay involved in communication and direction."],
  ["05", "Review", "You see the work, provide feedback, and help shape the result."],
  ["06", "Launch", "We put it into the real world and improve it when there's a reason to."],
];

export default function Home() {
  return (
    <main>
      <header className="nav shell">
        <a className="brand" href="#top">PM</a>
        <nav>
          <a href="#work">Work</a>
          <a href="#about">About</a>
          <a href="#contact">Contact</a>
        </nav>
      </header>

      <section id="top" className="hero shell">
        <p className="eyebrow">ROUTALK BUILD</p>
        <h1>PATRICK<br />MCVEY II</h1>
        <div className="heroBottom">
          <p className="lead">Turning business problems and ideas into practical digital solutions.</p>
          <a className="button" href="#contact">Tell me what you're working on</a>
        </div>
      </section>

      <section id="about" className="section shell split">
        <p className="sectionLabel">About</p>
        <div>
          <h2>Five years of learning how people, business, and technology connect.</h2>
          <p>For the past five years, I've worked across the digital and financial landscape, developing my skills in communication, technology, project development, and problem solving.</p>
          <p>Along the way, I've worked alongside talented developers, helped move ideas toward real projects, and learned what it takes to turn a conversation into something people can actually use.</p>
          <p>Today, I bring that experience to Routalk Build.</p>
        </div>
      </section>

      <section className="statement shell">
        <p>Understand first.</p>
        <p className="muted">Build second.</p>
      </section>

      <section className="section shell split">
        <p className="sectionLabel">What I do</p>
        <div>
          <h2>I start by listening.</h2>
          <p>I don't start with a predetermined solution. I start by understanding your business, what's working, what's getting in the way, and what you're trying to accomplish.</p>
          <p>From there, we determine where technology can provide a practical improvement.</p>
          <p className="callout">Bring me the problem. We'll help figure out what makes sense to build.</p>
        </div>
      </section>

      <section className="section shell">
        <p className="sectionLabel">What we can build</p>
        <div className="grid">
          {services.map(([title, text]) => (
            <article className="card" key={title}>
              <h3>{title}</h3>
              <p>{text}</p>
            </article>
          ))}
        </div>
      </section>

      <section id="work" className="section shell">
        <div className="sectionHead">
          <p className="sectionLabel">Selected work</p>
          <h2>Don't just take our word for it.</h2>
        </div>
        <p className="workIntro">Examples of work completed by Gabriel “Xin” Brázdil, the primary technical contractor I work with through Routalk Build.</p>
        <div className="projects">
          {projects.map((project, index) => (
            <article className="project" key={project.name}>
              <div className="projectVisual"><span>0{index + 1}</span></div>
              <div className="projectCopy">
                <p className="eyebrow">{project.type}</p>
                <h3>{project.name}</h3>
                <p>{project.text}</p>
              </div>
            </article>
          ))}
        </div>
        <p className="disclosure">Technical work shown above by Gabriel Brázdil. These projects were not originally developed for Routalk clients and are presented as examples of the technical capabilities available through our collaboration.</p>
      </section>

      <section className="global shell">
        <p className="sectionLabel">Built without borders</p>
        <h2>Different country.<br />Different language.<br /><span>No problem.</span></h2>
        <p>We can collaborate with businesses and organizations across borders and develop experiences for English-speaking, non-English-speaking, or multilingual audiences.</p>
        <div className="route">MILWAUKEE <span>→</span> EUROPE <span>→</span> ANYWHERE</div>
      </section>

      <section className="section shell">
        <p className="sectionLabel">How we work</p>
        <div className="steps">
          {steps.map(([num, title, text]) => (
            <article className="step" key={num}>
              <span>{num}</span>
              <h3>{title}</h3>
              <p>{text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="statement shell connection">
        <p>Business understanding</p>
        <p className="muted">+ technical execution.</p>
        <small>You shouldn't have to become a developer to build something valuable with technology.</small>
      </section>

      <section id="contact" className="contact shell">
        <p className="sectionLabel">Let's talk</p>
        <h2>Tell me what<br />you're working on.</h2>
        <p>You don't need a technical specification, a finished plan, or even the solution figured out. Tell me what you're trying to accomplish, improve, or solve. We'll start there.</p>
        <a className="button light" href="mailto:hello@example.com">Start a conversation</a>
        <footer>
          <span>Patrick McVey II</span>
          <span>Routalk Build</span>
        </footer>
      </section>
    </main>
  );
}
